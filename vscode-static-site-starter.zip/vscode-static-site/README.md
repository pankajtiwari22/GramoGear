# VS Code → Free Website → Deploy

This starter helps you build a static site in **Visual Studio Code** and deploy it **for free**.

## 1) Open in VS Code
- Download this folder, extract, then **File → Open Folder** in VS Code.

## 2) Edit
- Edit `index.html`, `styles.css`, `script.js` and save.

## 3) Preview locally
- Install the VS Code extension **Live Server**.
- Right‑click `index.html` → **Open with Live Server** (or run a simple HTTP server).

## 4) Initialize Git
```bash
git init
git add .
git commit -m "Initial commit"
```

## 5) Create GitHub repo & push
- Create a repo on GitHub (public).
- Then run (replace placeholders):
```bash
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## 6) Deploy (choose one)

### Option A: GitHub Pages (no build)
- On GitHub: **Settings → Pages → Build and deployment**
- **Source:** Deploy from a branch → **Branch:** `main` and **/ (root)` → Save.
- Your site will be live at: `https://YOUR_USERNAME.github.io/YOUR_REPO/`

### Option B: Netlify (drag‑and‑drop)
- Go to app.netlify.com → **New site from Git**
- Connect your GitHub repo and deploy.
- Or drag this folder into Netlify Drop: https://app.netlify.com/drop

### Option C: Vercel
- Go to vercel.com → **Add New… → Project**
- Import your GitHub repo and deploy.

## 7) Custom domain (optional)
- In GitHub Pages/Netlify/Vercel settings, add your domain and update DNS to the provided records.

---

Tips:
- Put images in `/assets` and reference them with `<img src="assets/…">`.
- Add `404.html` for single‑page apps and client‑side routing.
- For forms on static sites, use Netlify Forms, Formspree, or Google Forms.
