// Basic JS for menu + contact form demo
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

const menuBtn = document.getElementById('menuBtn');
const menu = document.getElementById('menu');
if (menuBtn && menu) {
  menuBtn.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    menuBtn.setAttribute('aria-expanded', String(open));
  });
}

const form = document.getElementById('contactForm');
const status = document.getElementById('status');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    // In static hosting, you'd use a form service (Netlify Forms, Formspree) – here we just simulate success.
    setTimeout(() => {
      status.textContent = `Thanks, ${data.name}! Your message has been 'sent'.`;
      form.reset();
    }, 400);
  });
}
